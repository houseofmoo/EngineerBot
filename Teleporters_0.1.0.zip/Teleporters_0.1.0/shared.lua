--Shared data interface between data and script, notably prototype names.

local data = {}

data.entities =
{
  teleporter = "teleporter"
}

return data
