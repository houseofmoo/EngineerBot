local require = function(name) return require("data/entities/"..name) end
require("teleporters/teleporters")
